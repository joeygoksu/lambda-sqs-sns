"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const aws_sdk_1 = require("aws-sdk");
const sqs = new aws_sdk_1.SQS();
// export const handler = async (event: SNSEvent) => {
const handler = (event, context, callback) => __awaiter(void 0, void 0, void 0, function* () {
    for (const record of event.Records) {
        const journalEntry = JSON.parse(JSON.stringify(record.Sns.Message));
        const balanced = isJournalEntryBalanced(journalEntry);
        console.log("👀 LOGGING ~ balanced", balanced);
        if (process.env.SQS_QUEUE_URL === undefined ||
            process.env.SQS_QUEUE_URL === "") {
            throw new Error("SQS_QUEUE_URL is not defined");
        }
        const sqsMessage = Object.assign(Object.assign({}, journalEntry), { balanced });
        try {
            // Send the journal entry message to the SQS queue
            yield sqs
                .sendMessage({
                QueueUrl: process.env.SQS_QUEUE_URL,
                MessageBody: JSON.stringify(sqsMessage),
            }, (err, data) => {
                if (err) {
                    console.log(err, err.stack);
                }
                else {
                    console.log(data);
                }
            })
                .promise();
            console.log("Message sent to SQS queue");
        }
        catch (error) {
            console.error(error);
            callback(error);
        }
        finally {
            callback(null, "success");
        }
    }
});
exports.handler = handler;
const isJournalEntryBalanced = (journalEntry) => {
    const lineItems = journalEntry["line-items"];
    let isBalanced = [];
    // return lineItems object with all properties unique by "account-id" key
    const key = "account-id";
    const arrayUniqueByKey = [
        ...new Map(lineItems.map((item) => [item[key], item])).values(),
    ];
    // Calculate the sum of all credits and debits in the journal entry
    for (const uniqueLineItem of arrayUniqueByKey) {
        const accountId = uniqueLineItem["account-id"];
        const creditSum = lineItems
            .filter((lineItem) => lineItem["account-id"] === accountId)
            .filter((lineItem) => lineItem.type === "credit")
            .reduce((sum, lineItem) => sum + lineItem.amount, 0);
        const debitSum = lineItems
            .filter((lineItem) => lineItem["account-id"] === accountId)
            .filter((lineItem) => lineItem.type === "debit")
            .reduce((sum, lineItem) => sum + lineItem.amount, 0);
        // A journal entry is balanced if the sum of credits equals the sum of debits
        isBalanced.push(creditSum === debitSum);
    }
    return isBalanced.every((item) => item === true);
};
